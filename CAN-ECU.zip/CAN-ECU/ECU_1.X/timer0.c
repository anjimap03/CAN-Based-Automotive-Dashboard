#include<xc.h>
#include"timer.h"
void init_timer0(void)
{
    TMR0 = 6;        // preload value

    T0CS = 0;        // internal clock
    PSA  = 1;        // no prescaler
    TMR0ON = 1;      // enable timer

    TMR0IF = 0;
    TMR0IE = 1;

    PEIE = 1;
    GIE  = 1;
}