
#include <xc.h>
#include "adc.h"
#include "clcd.h"
#include "msg_id.h"
#include "can.h"
#include "ecu1_sensor.h"
#include<stdio.h>
#include"dkp.h"

void init_config() {
    init_adc();
    //init_clcd();
     init_can();
    //init_matrix_keypad();
     init_digital_keypad();
   

}

void main(void) {
    init_config();
    unsigned char speed, str[10], pos;
    unsigned char msg_id, data1, data2, len1, len2;
    while (1) {
        speed = get_speed();
        can_transmit(SPEED_MSG_ID, &speed, 1);
       for (int i = 100; i--;);
//        can_receive(&msg_id, &data1, &len1);
//                sprintf(str,"%s",msg_id);
//                clcd_print(&msg_id, LINE1(0));

        pos = get_gear_pos();
        can_transmit(GEAR_MSG_ID, &pos, 1);
        //clcd_putch(pos + '0', LINE1(8));
        for (int wait = 200; wait--;);
//        can_receive(&msg_id, &data2, &len2);
//        if (msg_id == GEAR_MSG_ID) {
//            clcd_print("Gear", LINE1(11));
////            clcd_print("   ", LINE2(11));
//            clcd_print(gear[data2], LINE2(11));
//        }

    }


    return;
}
