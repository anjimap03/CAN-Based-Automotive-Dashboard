/* 
 * File:   timer.h
 * Author: Lenovo
 *
 * Created on April 28, 2026, 10:00 PM
 */

#ifndef TIMER_H
#define	TIMER_H
#define _XTAL_FREQ 20000000

volatile unsigned char blink_flag = 0;
volatile unsigned int tick = 0;

void init_timer0(void);

#endif	/* TIMER_H */

