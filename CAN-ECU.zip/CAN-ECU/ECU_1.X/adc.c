#include <xc.h>
#include "adc.h"

void init_adc(void)
{
    ADON = 1; //turn on the adc
    
    PCFG0 = 0;
    PCFG1 = 0;
    PCFG2 = 0;
    PCFG3 = 0; // to select all channel as analog
    
    VCFG0 = 0;// to select default reference voltage
    VCFG1 = 0;
    
    ADCS0 = 0;
    ADCS1 = 1;
    ADCS2 = 0;//to select 1 TAD = 1.6us
    
    ACQT0 = 0;
    ACQT1 = 1;
    ACQT2 = 0; // to select 4TAD as aquisition time
    
    
    ADFM = 1;//to select right justified
        
}

unsigned int read_adc(unsigned char channel)
{
    ADCON0 = (ADCON0 & 0xC3) | (channel << 2);
    
    GO = 1;//conversion started
    
    while(GO); 
    
    return (ADRESH << 8) | ADRESL;
      
}
