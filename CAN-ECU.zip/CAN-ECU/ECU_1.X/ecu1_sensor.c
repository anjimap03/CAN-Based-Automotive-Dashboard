
#include "ecu1_sensor.h"
#include "adc.h"
#include "can.h"
#include "msg_id.h"
#include"dkp.h"
uint16_t get_speed()
{
    // Implement the speed function
    unsigned char speed = (read_adc(CHANNEL4))/10.23;
    return speed;
    
}

unsigned char get_gear_pos()
{
    // Implement the gear function
    unsigned char key;
    static unsigned char i = 0;
    key = read_digital_keypad(STATE_CHANGE);

    if(key == GEAR_UP)
        {
            if(i < MAX_GEAR)
                i++;
        }
        else if(key == GEAR_DOWN)
        {
                if(i > 0)
                    i--;
        }
        else if(key == COLLISION)
        {
            i = 0;
        }
        return i;
}