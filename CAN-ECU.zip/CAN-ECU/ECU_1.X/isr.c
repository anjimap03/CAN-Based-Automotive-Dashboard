#include <xc.h>

// THIS is shared with sensor.c
volatile unsigned char blink_flag = 0;

void __interrupt() isr(void)
{
    static unsigned int count = 0;

    if (TMR0IF)
    {
        TMR0 = 6;        // reload
        TMR0IF = 0;

        count++;

        // ~500ms toggle
        if (count >= 20000)
        {
            blink_flag = !blink_flag;
            count = 0;
        }
    }
}