/* 
 * File:   mssg_id.h
 * Author: Lenovo
 *
 * Created on May 6, 2026, 11:50 AM
 */

#ifndef MSSG_ID_H
#define	MSSG_ID_H


#define SPEED_MSG_ID 0x10
#define GEAR_MSG_ID 0x20
#define RPM_MSG_ID 0x30
#define ENG_TEMP_MSG_ID 0x40
#define INDICATOR_MSG_ID 0x50

#endif	/* MSSG_ID_H */

