#include "ecu2_sensor.h"
#include "adc.h"
#include "can.h"
#include "mssg_id.h"
#include"dkp.h"

extern volatile IndicatorStatus prev_ind_status, cur_ind_status;

uint16_t get_rpm()
{
    unsigned int rpm;
    //Implement the rpm function
    rpm = (read_adc(CHANNEL4) / 10.23) ;
    
    return rpm;
}


IndicatorStatus process_indicator()
{
    unsigned char key;
    //Implement the indicator function
    key = read_digital_keypad(STATE_CHANGE);
        if(key == SWITCH1)
        {
            cur_ind_status = e_ind_left;
        }
        else if(key == SWITCH2)
        {
            cur_ind_status = e_ind_right;
        }
        else if(key == SWITCH3)
        {
           cur_ind_status = e_ind_hazard;
        }
        else if(key == SWITCH4)
        {
            cur_ind_status = e_ind_off;
        }
    return cur_ind_status;
}

