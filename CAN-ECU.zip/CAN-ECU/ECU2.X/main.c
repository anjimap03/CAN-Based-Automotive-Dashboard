/*
 * File:   main.c
 * Author: Lenovo
 *
 * Created on May 6, 2026, 11:56 AM
 */


#include <xc.h>
#include "adc.h"
#include "clcd.h"
#include"dkp.h"
#include "can.h"
#include "ecu2_sensor.h"
#include "mssg_id.h"

volatile IndicatorStatus prev_ind_status, cur_ind_status;

void init_config() {
    init_adc();
   // init_clcd();
   // init_matrix_keypad();
    init_can();
    init_digital_keypad();
}

void main(void) {
    init_config();

    unsigned int  flag;
    unsigned int rpm;

    while (1) {
        
        flag = process_indicator();
        can_transmit(INDICATOR_MSG_ID, &flag, 1);
        for (int wait = 5000; wait--;);

//        can_receive(&msg_id, &data2, &len2);
//
//        if (msg_id == INDICATOR_MSG_ID) {
//            clcd_print("Indicator", LINE1(7));
//            if (data2 == 1) {
//                clcd_print("<-  ", LINE2(11));
//            } else if (data2 == 2) {
//                clcd_print("<-->", LINE2(11));
//            } else if (data2 == 3) {
//                clcd_print("->  ", LINE2(11));
//            } else if (data2 == 4) {
//                clcd_print("OFF  ", LINE2(11));
//            }
//        }

        rpm = get_rpm();
        can_transmit(RPM_MSG_ID, &rpm, 2);
        for (int wait = 5000; wait--;);
//        can_receive(&msg_id, &data1, &len1);
////                data1 = rpm;
//
//        if (msg_id == RPM_MSG_ID) {
//            clcd_print("RPM", LINE1(0));
//            clcd_putch((data1 / 1000) + '0', LINE2(0));
//            clcd_putch((data1 / 100) % 10 + '0', LINE2(1));
//            clcd_putch((data1 / 10) % 10 + '0', LINE2(2));
//            clcd_putch((data1 % 10) + '0', LINE2(3));
//        }

        //        for(int wait = 2000;wait--;);


        //                for(int wait = 2000;wait--;);

    }
    return;
}

