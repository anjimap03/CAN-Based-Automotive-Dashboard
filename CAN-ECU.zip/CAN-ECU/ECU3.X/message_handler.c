#include <xc.h>
#include <string.h>
#include "message_handler.h"
#include "msg_id.h"
#include "can.h"
#include "clcd.h"

extern int flag;
volatile unsigned char led_state = LED_OFF, status = e_ind_off;
unsigned char gear[8][3] = {"N", "G1", "G2", "G3", "G4", "G5", "GR", "_c"};

void handle_speed_data(uint8_t *data, uint8_t len)

{
    //Implement the speed function
   clcd_print("Speed", LINE1(0));
   clcd_putch(((*data) / 100) + '0', LINE2(0));
   clcd_putch((((*data) / 10) % 10) + '0', LINE2(1));
   clcd_putch(((*data) % 10) + '0', LINE2(2));
}

void handle_gear_data(uint8_t *data, uint8_t len) 
{
    //Implement the gear function
     clcd_print("Gear", LINE1(11));
     clcd_print(gear[(*data)], LINE2(11));
}

void handle_rpm_data(uint8_t *data, uint8_t len) 
{
    uint16_t rpm=(*data)*60;
    //Implement the rpm function
    clcd_print("RPM", LINE1(0));
    clcd_putch(((rpm) / 1000) + '0', LINE2(0));
    clcd_putch(((rpm) / 100) % 10 + '0', LINE2(1));
    clcd_putch(((rpm) / 10) % 10 + '0', LINE2(2));
    clcd_putch(((rpm ) % 10) + '0', LINE2(3));
}

void handle_indicator_data(uint8_t *data, uint8_t len) 
{
    //Implement the indicator function
    clcd_print("Indicator", LINE1(7));
    if ((*data) == e_ind_left)
    {
        if(flag==1)
        {
            clcd_print("<-  ", LINE2(11));
            LEFT_IND_ON();
            RIGHT_IND_OFF();
        }
        else
        {
            clcd_print("    ", LINE2(11));
            LEFT_IND_OFF();
            RIGHT_IND_OFF();
        }       
    } 
    else if ((*data) == e_ind_right)
    {
        if(flag==1)
        {
            clcd_print("->", LINE2(11));
            RIGHT_IND_ON();
            LEFT_IND_OFF();
        }
        else
        {
            clcd_print("    ", LINE2(11));
            LEFT_IND_OFF();
            RIGHT_IND_OFF();
        }       
    } 
    else if ((*data) == e_ind_hazard) 
    {
        if(flag==1)
        {
            clcd_print("<- ->  ", LINE2(11));
            RIGHT_IND_ON();
            LEFT_IND_ON();
        }
        else
        {
            clcd_print("       ", LINE2(11));
            LEFT_IND_OFF();
            RIGHT_IND_OFF();
        }  
    } 
    else if ((*data) == e_ind_off)
    {
        clcd_print("OFF  ", LINE2(11));
        LEFT_IND_OFF();
        RIGHT_IND_OFF();
    }
}

#define RIGHT_IND_ON() (PORTB = PORTB | 0xC0)
#define RIGHT_IND_OFF() (PORTB = PORTB & ~0xC0)
#define LEFT_IND_ON() (PORTB = PORTB | 0x03)
#define LEFT_IND_OFF() (PORTB = PORTB & ~0x03)

void process_canbus_data() 
{   
    //process the CAN bus data
    char msg_id;
   unsigned int rx_data,rx_len;
    can_receive(&msg_id, &rx_data,&rx_len);
    
    if(msg_id==SPEED_MSG_ID)
        handle_speed_data(&rx_data,rx_len); 
    else if(msg_id==GEAR_MSG_ID)
        handle_gear_data(&rx_data,rx_len);
    else if(msg_id==RPM_MSG_ID)
       handle_rpm_data(&rx_data,rx_len);
    else if(msg_id==INDICATOR_MSG_ID)
       handle_indicator_data(&rx_data,rx_len);       
}
