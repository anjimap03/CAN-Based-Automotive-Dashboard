#include <xc.h>
int flag;
void __interrupt() isr(void)
{
    static unsigned int count = 0;
    if(TMR0IF == 1)
    {
        TMR0 = TMR0+8;//interrupt latency (progrm counter and stack pointer) and 2instructions(+,=)
        if(count++ == 20000)
        {
            count = 0;
            flag = !flag; 
        }
        TMR0IF = 0;
    }
}

