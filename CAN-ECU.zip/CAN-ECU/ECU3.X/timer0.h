/* 
 * File:   timer0.h
 * Author: Lenovo
 *
 * Created on May 6, 2026, 2:03 PM
 */

#ifndef TIMER0_H
#define	TIMER0_H
void init_timer0(void);


#endif	/* TIMER0_H */

